package com.example.colorapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColorApiJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColorApiJavaApplication.class, args);
	}

}
