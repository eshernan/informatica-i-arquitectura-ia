package com.example.colorapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColorApiJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
